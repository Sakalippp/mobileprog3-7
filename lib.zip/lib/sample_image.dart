import 'package:flutter/material.dart';

class SampleImage extends StatelessWidget {
  const SampleImage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('yahaha hayyuk'),
      ),
      body: Column(
        children: [
          Image.network('assets/alvares.jpg'),
          Column(
            children: [
              const CircleAvatar(
                radius: 50,
                backgroundImage: AssetImage('assets/alvares.jpg'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
