import 'package:flutter/material.dart';

class SampleListView extends StatelessWidget {
  SampleListView({super.key});
  final List colorCodes = [900, 800, 700, 600, 500, 400, 300, 200, 100];

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('celemek'),
//       ),
//       body: ListView(
//         reverse: true,
//         padding: const EdgeInsets.all(10),
//         children: [
//           Container(
//             color: Colors.amber,
//             height: 100,
//           ),
//           Container(
//             color: Color.fromARGB(255, 236, 200, 137),
//             height: 100,
//           ),
//           Container(
//             color: Colors.amber,
//             height: 100,
//           ),
//           Container(
//             color: Color.fromARGB(255, 73, 59, 35),
//             height: 100,
//           ),
//           Container(
//             color: Colors.amber,
//             height: 100,
//           ),
//           Container(
//             color: const Color.fromARGB(255, 124, 121, 113),
//             height: 100,
//           ),
//           Container(
//             color: const Color.fromARGB(255, 231, 192, 125),
//             height: 100,
//           ),
//         ],
//       ),
//     );
//   }
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Belajar Widget list view Horizontal'),
      ),
      body: Container(
        height: 130,
        child: ListView.builder(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.all(10),
          itemBuilder: (context, index) {
            return CircleAvatar(
              radius: 60,
              child: CircleAvatar(
                radius: 50,
                backgroundColor: Colors.blue,
                backgroundImage: AssetImage('alvares.jpg'),
              ),
            );
          },
          itemCount: colorCodes.length,
        ),
      ),
    );
  }
}
